import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FirstSelenumScript {
	public static void main(String arg[]) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");// launch the url 
			
		driver.manage().window().maximize();
		
		//Implicit Wait
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); //NoSuchElementException
		
		
		
		//Explicit Wait
		
		WebDriverWait wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inputUsernam")));
		
		WebElement username = driver.findElement(By.id("inputUsernam"));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("inputPassword")));
		WebElement password = driver.findElement(By.name("inputPassword"));
		
		username.sendKeys("username");
		password.sendKeys("Password");
		
		//driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("password");
		
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[id='chkboxOne']")).click();
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		
		
		//driver.navigate().to("https://rahulshettyacademy.com/locatorspractice/");
		
	}

}
