import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MakemyTrip {
	
	static WebDriver driver=null;
	
	public static void launchBrowser() {
		try {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");	
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.makemytrip.com/");
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	
	public static void bookTicket() {
		try {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");	
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.makemytrip.com/");
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
}