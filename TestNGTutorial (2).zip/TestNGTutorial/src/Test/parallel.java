package Test;

import java.io.File;
//import apache.commons.io;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;


public class parallel {
	static WebDriver  driver;
	@Test
	public static void launch() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://demo.guru99.com/");
		
	} 
	@Test
	public static void launch1() {
		System.setProperty("webdriver.ie.driver","C:\\Users\\686398\\Downloads\\IEDriverServer_Win32_4.0.0\\IEDriverServer.exe");
		WebDriver driver1=new InternetExplorerDriver();
		driver1.get("http://demo.guru99.com/");
		
		
	}

}
