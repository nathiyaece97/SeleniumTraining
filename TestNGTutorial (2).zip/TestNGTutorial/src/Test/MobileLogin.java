package Test;

import org.testng.annotations.*;

public class MobileLogin {
	
	@Test(timeOut=4000)
	public void mobileLaunchURL() {
		System.out.println("Mobile URL launched");
	}
	
	@Test (groups= {"sample","test"})
	public void mobileLogin() {
		System.out.println("Mobile Application Login successful");
		
	}
	@Test
	public void mobileLoginVerification() {
		System.out.println("Mobile Application Login verified");
		
	}
}
