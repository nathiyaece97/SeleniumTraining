package Test;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class GroupingAndDataProvider {
	
	

	@Test(dataProvider ="getdata")
	public void demo(String username, String pass) {
		System.out.println("Demo"+username+" "+pass);
	}
	
	@Test(groups= {"sample"})
	public void apiTest() {
		System.out.println("Hello API");
	}

	@DataProvider(name="getdata")
	public Object[][] getdata(){
		Object [][]a =new Object[1][2];
		a[0][0] = "name";
		a[0][1] = "value";
		return a;
		
	}
}
