package Test;

import org.testng.annotations.Test;

public class WebLogin {

	@Test
	public void webLaunchURL() {
		System.out.println("Web URL launched");
	}
	
	@Test(groups= {"sample"})
	public void webLogin() {
		System.out.println("Web Application Login successful");
		
	}
	@Test
	public void webLoginVerification() {
		System.out.println("Web Application Login verified");
		
	}
}

