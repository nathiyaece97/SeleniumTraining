package Test;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class parameterization {	

	@Test
	//@Parameters({"url"})
	public void launchUrl() {
		System.out.println("url");
	}
	
	@Test
	@Parameters({"username" , "password"})
	public void parameter(String user, String pass) {
		System.out.println(user +" "+pass);
	}
	
	@Test(dataProvider = "inputdata")
	public void getUserinput(String user, String pass) {
		System.out.println("user data");
		System.out.println(user +" "+pass);
	}
	
	
	@DataProvider(name ="inputdata")
	public  Object[][] getData() {
		Object [][]obj = new Object[3][2];
		//1st iteration
		obj[0][0] = "correctuser";
		obj[0][1] = "correctpassword";
		
		//2nd iteration
		obj[1][0] = "incorrectuser";
		obj[1][1] = "correctpassword";
		
		//3rd iteration
		obj[2][0] = "correctuser";
		obj[2][1] = "incorrectpassword";
		
		return obj;
		
	}

}
