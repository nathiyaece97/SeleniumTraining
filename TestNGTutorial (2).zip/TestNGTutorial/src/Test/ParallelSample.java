package Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ITestListener;
import org.testng.ITestNGListener;
import org.testng.annotations.Test;

public class ParallelSample {
	
 static WebDriver driver;
	@Test
	public void samplemethod1() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://demo.guru99.com/");
	}
	@Test
	public void sampleMethod2() {
		System.setProperty("webdriver.ie.driver","C:\\Users\\686398\\Downloads\\IEDriverServer_Win32_4.0.0\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
		driver.get("http://demo.guru99.com/");
	}
}
