import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		WebElement dropdown = driver.findElement(By.id("dropdown-class-example"));
		
		Select select = new Select(dropdown);
		//select.selectByIndex(1);
		//select.selectByValue("option3");
		select.selectByVisibleText("Option2");
		
		WebElement option = select.getFirstSelectedOption();
		System.out.println(option.getText());
		
		
		List<WebElement> al= select.getOptions();
		
		for(WebElement a : al)
			System.out.println(a.getText());
		

	}

}
