package ListenerDemo;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerDemo.Listenerinterface.class)

public class listenerclass {
	static WebDriver driver;
	
	@Test
	public void sample1() {
		System.out.println("sample method1");
	}
	
	@Test
	public void sample2() {
		System.out.println("sample method2");
		
		Assert.assertTrue(false);
		//Assert.assertEquals(expected, actual);
		
		
		
		
	}

}
