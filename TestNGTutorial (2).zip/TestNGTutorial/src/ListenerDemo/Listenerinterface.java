package ListenerDemo;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;

import java.io.File;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listenerinterface implements ITestListener{

	    @Override		
	    public void onTestFailure(ITestResult arg0) {					
	        // TODO Auto-generated method stub	
	    	
	    	System.out.println("Test got failed "+ arg0.getName());
	    	Reporter.log("test failed"+arg0.getName());	  
	    	Reporter.log("nbnbmnm",ITestResult.SUCCESS);
	        		
	    }		

	    @Override		
	    public void onTestSkipped(ITestResult arg0) {					
	        // TODO Auto-generated method stub				
	        		
	    }		

	    @Override		
	    public void onTestStart(ITestResult arg0) {					
	        // TODO Auto-generated method stub				
	        		
	    }		

	    @Override		
	    public void onTestSuccess(ITestResult arg0) {
	    	System.out.println("Test case got passed "+arg0.getName());
	    	Reporter.log("pass");
	        // TODO Auto-generated method stub				
	        		
	    }		

}
