package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.ReusableFunction;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	static ReusableFunction obj;
	static WebDriver driver;


	@When("Enter username {string} and password {string}")
	public void enter_username_and_password(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}



	
	
	@Given("User should be in the login page")
	public void user_should_be_in_the_login_page() {
	  obj= new ReusableFunction();
	  driver = obj.invokeWebDriver();
	  driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
	}
	
	@When("Enter username and password")
	public void enter_username_and_password() {
		driver.findElement(By.id("email")).sendKeys("username");
	    throw new io.cucumber.java.PendingException();
	}
	@When("click sign in button")
	public void click_sign_in_button() {
		
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("User is in the home page")
	public void user_is_in_the_home_page() {
		
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}




}
