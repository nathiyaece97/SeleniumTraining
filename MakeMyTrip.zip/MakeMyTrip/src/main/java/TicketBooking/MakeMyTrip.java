package TicketBooking;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class MakeMyTrip {	
	static WebDriver driver=null;
	static WebDriverWait wait=null;
	static JavascriptExecutor js=null;
	
	// ************************** Launch Browser ************************************
	@BeforeTest
	public static void launchBrowser() {
	//	try {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");	
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.makemytrip.com/");
			 js = (JavascriptExecutor) driver;
			// js.executeScript("arguments[0].click();", driver.findElement(By.xpath("(//span[text()='Hotels'])[1]")));
			
			
	/*	}
		catch(Exception e) {
			System.out.println(e);
		} */
	}
	
// *********************************** Explicit wait ***************************************
	
	public static void webDriverwait_xpath(String xpathval) {
		wait = new WebDriverWait (driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathval)));
	}
	
	public static void webDriverwait_id(String idval) {
		wait = new WebDriverWait (driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(idval)));
	}
	
// *************************************** Handle multiple window *************************
	
	public static void handleWindows() {
		String curentwin =  driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for(String child : windows) {
			if(!child.equals(curentwin)) {
				driver.switchTo().window(child);
			}
		}
	}
	
// ***************************** Book Flight *********************************************
	
	@Test(priority=0)
	public static void bookTicket() {
		try {
			
			//driver.findElement(By.xpath("//label[text()='Login with Phone/Email']")).click();
			
			// select From City
			webDriverwait_id("fromCity");
			Thread.sleep(3000);
			 js.executeScript("arguments[0].click();", driver.findElement(By.id("fromCity")));
			driver.findElement(By.id("fromCity")).click();
			Thread.sleep(2000);
			webDriverwait_xpath("//input[@id='fromCity']//following::input[1]");
			driver.findElement(By.xpath("//input[@id='fromCity']//following::input[1]")).sendKeys("Chennai");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//ul[@role='listbox']/li[1]")).click();
			
			//select To city
			webDriverwait_xpath("//input[@id='toCity']//following::input[1]");
			driver.findElement(By.xpath("//input[@id='toCity']//following::input[1]")).sendKeys("Lond");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//ul[@role='listbox']/li[1]")).click();
			
			//close advertisement if avaiable
			try {
				WebElement ad= driver.findElement(By.xpath("//span[@class='langCardClose']"));
				if(ad.isDisplayed()) {
					ad.click();
					Thread.sleep(2000);
				}
			}
			catch(Exception e) {
				System.out.println("AD closed");
			}
			
			//Find 90 days from current date
			DateFormat dateformat= new SimpleDateFormat("MM/dd/yyyy");
			Calendar c= Calendar.getInstance();
			c.add(Calendar.DATE, 90);
			String date = dateformat.format(c.getTime());
			String month=date.split("/")[0];
			String day = date.split("/")[1];
			
			//Select date from date picker
			webDriverwait_xpath("//span[@aria-label='Next Month']");
			for(int i=0;i<2;i++) {
				driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
				Thread.sleep(1000);
			}
			
			
			
			WebElement dateselect = driver.findElement(By.xpath("(//div[@class='DayPicker-Month'])[2]//p[text()='"+day+"']"));
			webDriverwait_xpath("(//div[@class='DayPicker-Month'])[2]//p[text()='"+day+"']");
			js.executeScript("arguments[0].scrollIntoView(false);", dateselect);
			Thread.sleep(2000);
			dateselect.click();
			
			//click Search
			driver.findElement(By.xpath("//a[text()='Search']")).click();
			Thread.sleep(5000);
			
			//click the popup if available
			try {
				if(driver.findElement(By.xpath("//button[text()='OKAY, GOT IT!']")).isDisplayed()) {
					driver.findElement(By.xpath("//button[text()='OKAY, GOT IT!']")).click();
				}
			}
			catch(Exception e) {
				
			}
			
			//Select the first result and click book now
			//driver.navigate().refresh();
			//Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,350)");
			webDriverwait_xpath("(//span[text()='View Prices'])[1]");
			WebElement viewprice=driver.findElement(By.xpath("(//span[text()='View Prices'])[1]"));
			js.executeScript("arguments[0].scrollIntoView(false);", viewprice);
			viewprice.click();
			Thread.sleep(3000);
			
			try {
				if(driver.findElement(By.xpath("//button[text()='Book Now']")).isDisplayed()) {
					js.executeScript("arguments[0].scrollIntoView(false);", driver.findElement(By.xpath("//button[text()='Book Now']")));
					driver.findElement(By.xpath("//button[text()='Book Now']")).click();
				}
			}
			catch(Exception e) {
				webDriverwait_xpath("//button[text()='Continue']");
				driver.findElement(By.xpath("//button[text()='Continue']")).click();
			}
			
			
			
			//switch to child window
			handleWindows();
			webDriverwait_xpath("//span[text()='I have read and understood all the above mentioned information']");
			WebElement con = driver.findElement(By.xpath("//span[text()='I have read and understood all the above mentioned information']"));
			js.executeScript("arguments[0].scrollIntoView(false);", con);
			con.click();
			Thread.sleep(5000);
			webDriverwait_xpath("//b[text()='Yes, Secure my trip. ']");
			js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//b[text()='Yes, Secure my trip. ']")));
			Thread.sleep(1000);
			driver.findElement(By.xpath("(//span[@class='customRadioBtn'])[1]")).click();
				
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
// ******************************** Add traveller information ********************************
	@Test(priority=1)
	public void addTraveller() {
		try {
			WebElement addtraveller = driver.findElement(By.className("addTravellerBtn"));
			js.executeScript("arguments[0].scrollIntoView(false);", addtraveller);
			Thread.sleep(3000);
			addtraveller.click();
			
			WebElement passport = driver.findElement(By.xpath("//input[@placeholder='Passport No']"));
			js.executeScript("arguments[0].scrollIntoView(true);", passport);
			
			String firstname="Sample";
			String lastname = "Test";
			String nationality = "India";
			String passportno = "Pass123";
			String passportcountry = "India";
			String DOBDate = "01";
			String DOBMonth = "Jan";
			String DOBYear="1995";
			String expiryDay="03";
			String expiryMonth="Feb";
			String expiryYear="2024";
			driver.findElement(By.xpath("//input[@placeholder='First & Middle Name']")).sendKeys(firstname);
			driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastname);
			Thread.sleep(2000);
			try {
				driver.findElement(By.xpath("(//div[text()='Nationality']//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
				driver.findElement(By.xpath("//*[text()='India']")).click();
			}
			catch(Exception e) {
				System.out.println("nationality"+e);
			}
			
			//driver.findElement(By.xpath("//div[text()='Nationality']")).sendKeys(nationality);
			try {
				driver.findElement(By.xpath("//input[@placeholder='Passport No']")).click();
				driver.findElement(By.xpath("//input[@placeholder='Passport No']")).sendKeys(passportno);
			}
			catch(Exception e) {
				System.out.println("passport no"+e);
			}
			
			try {
				driver.findElement(By.xpath("(//div[text()='Passport Issuing Country']//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
				//driver.findElement(By.xpath("(//*[text()='India'])[2]")).click();
				driver.findElement(By.xpath("(//*[text()='"+passportcountry+"'])[2]")).click();
			}catch(Exception e) {
				System.out.println("passport issuing country"+e);
			}
			
			
			//driver.findElement(By.xpath("//div[text()='Passport Issuing Country']")).sendKeys(passportcountry);
			
			
			
			try {
				//driver.findElement(By.xpath("//span[text()='MALE']")).click();
				//date of birth
				driver.findElement(By.xpath("((//div[text()='Date'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
				driver.findElement(By.xpath("//*[text()='"+DOBDate+"']")).click();
				driver.findElement(By.xpath("((//div[text()='Month'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
				driver.findElement(By.xpath("//*[text()='"+DOBMonth+"']")).click();
				driver.findElement(By.xpath("((//div[text()='Year'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
				js.executeScript("arguments[0].scrollIntoView(false);", driver.findElement(By.xpath("//*[text()='"+DOBYear+"']")));
				driver.findElement(By.xpath("//*[text()='"+DOBYear+"']")).click();
				
			}
			catch(Exception e) {
				System.out.println("DOB"+e);
			}
			
			
			driver.findElement(By.xpath("((//div[text()='Date'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
			driver.findElement(By.xpath("//*[text()='"+expiryDay+"']")).click();
			driver.findElement(By.xpath("((//div[text()='Month'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
			driver.findElement(By.xpath("//*[text()='"+expiryMonth+"']")).click();
			driver.findElement(By.xpath("((//div[text()='Year'])[1]//following::div[contains(@class,'dropdown__indicator')])[1]")).click();
			js.executeScript("arguments[0].scrollIntoView(false);", driver.findElement(By.xpath("//*[text()='"+DOBYear+"']")));
			driver.findElement(By.xpath("//*[text()='"+expiryYear+"']")).click();	

	}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	@Test(priority=2)
	public void enterContactdetails() {
		try {
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@placeholder='Mobile No']")).sendKeys("1234567809");
			driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("abc@gmail.com");
			
			webDriverwait_xpath("//button[text()='Continue']");
			driver.findElement(By.xpath("//button[text()='Continue']")).click();
			
			webDriverwait_xpath("//button[text()='CONFIRM']");
			driver.findElement(By.xpath("//button[text()='CONFIRM']")).click();
			
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
}
