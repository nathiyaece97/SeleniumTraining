package stepDefinitions;

import java.util.List;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {

	@Given("User should be in the login page")
	public void user_should_be_in_the_login_page() {
	    System.out.println("User is in Login Page");
	   
	}


	@When("Enter the user details {string}")
	public void enter_the_credentials(String string) {
		
		 System.out.println("User is in Login Page"+string +"    ");
	    
	} 
	
	@When("^Enter the (.+) and (.+)$")
	public void enter_the_and(String username, String password) throws Throwable {
		 System.out.println("User is in Login Page"+username +"    "+password);
	}
	
	//Using Data Table
	@When("^Enter the below details")
	public void enter_the_credentialsdata(DataTable data) throws Throwable {
		
		List<List<String>> al = data.asLists();
		System.out.println("Username : "+al.get(0).get(0));
		System.out.println("Username : "+al.get(0).get(1));
	}
	
	
	@Then("User should be in Landing page")
	public void user_should_be_in_landing_page() {
		 System.out.println("Logged in successfully. User is in Landing page");
	   
	}




}
