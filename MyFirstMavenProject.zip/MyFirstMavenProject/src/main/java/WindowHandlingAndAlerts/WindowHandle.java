package WindowHandlingAndAlerts;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("openwindow")).click();
		System.out.println("parent window :"+ driver.getTitle());
		
		
		// Handling Multiple Windows
		String parentwindow = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		
		for(String child : windows) {
			
			if(!child.equals(parentwindow)) {
				driver.switchTo().window(child);
				System.out.println("child window :"+ driver.getTitle());
				driver.close();	
			}
			
		}
		driver.switchTo().window(parentwindow);
		//driver.close();
		
		//Handle multiple Tabs
		
		driver.findElement(By.id("opentab")).click();
		
		String parenttab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		
		for(String child : tabs) {
			
			if(!child.equals(parenttab)) {
				driver.switchTo().window(child);
				System.out.println("child window :"+ driver.getTitle());
				driver.close();	
			}
			
		}
		driver.switchTo().window(parenttab);
		
		
		
	}
	
	
	
	

}
