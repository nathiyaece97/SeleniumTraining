package Sample;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsclassinSelenium {

	static WebDriver driver;
	
	// *********************** Launch browser ********************
		public void launchBrowser() {
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			driver = new ChromeDriver();
			//driver.get("https://demo.guru99.com/test/drag_drop.html");
			driver.get("https://rahulshettyacademy.com/AutomationPractice/");
			driver.manage().window().maximize();
		}
		
	public void performAction() throws Exception {
		
		Actions action = new Actions(driver);
		//action.contextClick().perform();  // build(), perform()
	//	Thread.sleep(3000);	
		
		// Click and hold
		
		//WebElement alert = driver.findElement(By.id("alertbtn"));
		//action.clickAndHold(alert);
		
		//drag and drop
		/*WebElement src= driver.findElement(By.xpath("(//a[contains(text(),'5000')])[2]"));
		WebElement des= driver.findElement(By.xpath("(//div[@class='ui-widget-content'])[3]"));
		
		action.dragAndDrop(src, des).perform();
		Thread.sleep(4000);
		
		action.keyDown(Keys.ALT).keyUp(Keys.ALT).keyDown(Keys.ENTER).keyUp(Keys.ENTER).perform(); */
		
		//Mouse Hover
		
		WebElement hover= driver.findElement(By.id("mousehover"));
		action.moveToElement(hover).perform();
		driver.findElement(By.xpath("//a[text()='Reload']")).click();
		Thread.sleep(3000);
		
		
		
	}
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		ActionsclassinSelenium obj= new ActionsclassinSelenium();
		obj.launchBrowser();
		obj.performAction();
		
		

	}

}
