package Sample;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		//launching url
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		
		//Handling dropdown using Select class
		
		WebElement dropdown = driver.findElement(By.id("dropdown-class-example"));
		Select select = new Select(dropdown);
		
		select.selectByIndex(1);
		Thread.sleep(2000);
		select.selectByValue("option2");
		Thread.sleep(2000);
		select.selectByVisibleText("Option3");
		Thread.sleep(2000);
		
		WebElement text = select.getFirstSelectedOption();
		
		String textval = text.getText();
		
		if(textval.equals("Option3")) {
			System.out.println("Value selcted correctly");
		}
		else {
			System.out.println("Value not selcted correctly");
		}
		
	// Handling dropdown using List (findElemets)
		
		//using list
		List<WebElement> dropdownoption=driver.findElements(By.xpath("//select[@id='dropdown-class-example']/option"));
		
		dropdown.click();
		Thread.sleep(2000);
		
		String option="Option1";
		
		for(int i=0;i<dropdownoption.size();i++) {
			
			String text1 =dropdownoption.get(i).getText();
			
			System.out.println(text1);
			if(text1.equals(option)) {
				dropdownoption.get(i).click();
			}
			
		}
		
		
		
		

	}

}
