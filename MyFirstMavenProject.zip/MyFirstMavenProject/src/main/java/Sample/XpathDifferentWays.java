package Sample;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class XpathDifferentWays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); //default pooling time is 500 Millisecond
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='radioButton1']")));
		
		WebElement radio1 = driver.findElement(By.xpath("//input[@class='radioButton1']"));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("checkBoxOption1")));
		WebElement check1 = driver.findElement(By.id("checkBoxOption1"));
		radio1.click();
		check1.click();
		
		//isSelected - radiobutton, check box
		//isDisplayed - 
		
		
		if(check1.isSelected()) {
			System.out.println("checkbox already selected");
		}
		else {
			check1.click();
		}
		
		
		
		
	}

}
