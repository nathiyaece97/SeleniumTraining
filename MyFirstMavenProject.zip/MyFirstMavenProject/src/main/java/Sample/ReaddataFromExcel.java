package Sample;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReaddataFromExcel {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		File file= new File("C:\\Users\\686398\\OneDrive - Cognizant\\Desktop\\Datasheet.xlsx");
		
		//XSSFWorkbook  - .xlsx
		//HSSFWorkbook  - .xls
		
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		int rownum = sheet.getLastRowNum();
		
		for(int i=0;i<rownum;i++) {
			String username  = sheet.getRow(i).getCell(0).getStringCellValue();
		}
		
		System.out.println(sheet.getSheetName());
		
		String username  = sheet.getRow(1).getCell(0).getStringCellValue();
		String password = sheet.getRow(1).getCell(2).getStringCellValue();
		System.out.println(username+" "+password);
		
		
		
		
		
		
		
		
		
		

	}

}
