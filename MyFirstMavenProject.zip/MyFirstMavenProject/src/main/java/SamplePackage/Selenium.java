package SamplePackage;

public class Selenium {

	public static Selenium enterUsername(String username) {
		System.out.println("Enter user name"+username);
		return new Selenium();
		
	}
	
	public static Selenium enterPassword(String password) {
		System.out.println("Enter password"+password);
		return new Selenium();
	}
	
	public static Selenium clickLoginBtn() {
		System.out.println("Login clicked");
		return new Selenium();
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Selenium.enterUsername("username").enterPassword("password").clickLoginBtn();
		
		//driver.manage().window().maximize();

	}

}
