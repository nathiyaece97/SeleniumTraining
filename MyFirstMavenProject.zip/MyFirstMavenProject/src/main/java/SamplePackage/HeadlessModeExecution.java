package SamplePackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class HeadlessModeExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--headless");
		
	/*	DesiredCapabilities capability = new DesiredCapabilities();
		capability.setCapability(ChromeOptions.CAPABILITY, option);
		option.merge(capability);*/
		
		WebDriver driver=new ChromeDriver(option);
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		System.out.println(driver.getTitle());
		
	}

}
