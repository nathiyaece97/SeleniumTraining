package SamplePackage;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SeleniumSample {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		String browser="";
		
		Scanner sc= new Scanner(System.in);
		browser = sc.next();
		
		 WebDriver driver = null;
		 
		 
		
		if(browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
			 driver=new ChromeDriver();
		}
		else if(browser.equals("IE")) {
			System.setProperty("webdriver.ie.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
			 driver=new InternetExplorerDriver();
		}
		
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		//driver.findElement(By.id("confirmbtn")).click();
	//	Thread.sleep(3000);

		//Alert Handling
		
	/*	System.out.println(driver.switchTo().alert().getText());
		//driver.switchTo().alert().accept();
		driver.switchTo().alert().dismiss();
		
		//driver.switchTo().alert().sendKeys(""); */
		
		driver.findElement(By.id("openwindow")).click();
		Thread.sleep(3000);
		
		
		//Window Handling
		String currentwindow = driver.getWindowHandle();
		System.out.println(driver.getTitle());
		
		Set<String> window = driver.getWindowHandles();
		
		for(String win : window) {
			if(!win.equals(currentwindow)) {
				driver.switchTo().window(win);
				System.out.println(driver.getTitle());
			}
		}
		
		driver.switchTo().defaultContent();
		
		
		driver.switchTo().frame("");
		
		driver.findElements(By.cssSelector("iframe[id='courses-iframe']"));
		
		
		//
		
		
		List<WebElement> elements = driver.findElements(By.xpath("//div[@class='detail-list']/ul/li/div[2]/a"));
		for( WebElement ele : elements) {
			if(ele.getText().equals("A M Es Dental College")) {
				System.out.println("Value is present");
				
			}
		}
		
		
		
		
		
		
		
		

	}

}
