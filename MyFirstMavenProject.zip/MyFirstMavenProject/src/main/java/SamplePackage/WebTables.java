package SamplePackage;

import java.io.File;
import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebTables {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
         
		WebDriver driver=new ChromeDriver();
		//driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		//driver.get("https://demo.guru99.com/test/drag_drop.html");
		//tables
		
	/*	WebElement table=driver.findElement(By.xpath("//table[@name='courses']"));
		
		List<WebElement> row = driver.findElements(By.xpath("//table[@name='courses']/tbody/tr"));
		int rowcount= row.size();
		
		List<WebElement> column = driver.findElements(By.xpath("//table[@name='courses']/tbody/tr/th"));
		int cosize= column.size();
		
		System.out.println(rowcount +"  "+cosize);
		
		for(int i=2;i<rowcount;i++) {
			System.out.println("//table[@name='courses']/tbody/tr["+i+"]/td[2]");
			String text = driver.findElement(By.xpath("//table[@name='courses']/tbody/tr["+i+"]/td[2]")).getText();
			System.out.println(text);
		}
		*/
		
		//Action
		Actions action =new Actions(driver);
		//action.contextClick().perform();
		//action.doubleClick().perform();
		
		//key down - to press any key
		//key up - to release key
		
	//	action.keyDown(Keys.CONTROL).keyUp(Keys.CONTROL).perform();
		
	/*	action.moveToElement(driver.findElement(By.id("mousehover"))).contextClick().build().perform();
		
		
		WebElement source = driver.findElement(By.xpath("//a[text()=' 5000 ']"));
	    WebElement target = driver.findElement(By.xpath("(//h3[contains(text(),'DEBIT SIDE')]//following::h3[contains(text(),'Amount')])[1]//following::li[1]"));
				
		action.dragAndDrop(source, target).build(); */
		
	/*	String text = source.getAttribute("value");
		System.out.println("getAttribute: "+ text);
		
		String text1 = source.getText();
		System.out.println("getText: "+ text1); */
		
	/*	driver.get("https://webapps.tekstac.com/Agent_Registration/");
		driver.findElement(By.id("submit")).click();
		
		//Thread.sleep(3000);
		System.out.println(driver.findElement(By.id("message")).getText()); */
		
       //handling ad popup
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		
	/*	ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("c://extension_3_40_1_0.crx")); 
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver1 = new ChromeDriver(options);
		driver1.get("https://www.ishahomes.com/");
		Thread.sleep(15000); */
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.findElement(By.xpath("//input[@value='radio1']")).click();
		try {
			if(driver.findElement(By.xpath("//input[@value='radio2']")).isSelected()) {
				System.out.println("Yes Radio button selected");
			}
			else {
				System.out.println("Radio button not selected");
			}
		}
		catch(Exception e) {
			
		}
	
		
		
		
		
		
	}

}
