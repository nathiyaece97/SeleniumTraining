package SamplePackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExcelSheet {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		String username;
		
		FileInputStream inputstream = new FileInputStream("C:\\Users\\686398\\OneDrive - Cognizant\\Desktop\\Datasheet.xlsx");
		//XSSFWorkbook xsf = new 	XSSFWorkbook();
		

	}

}
