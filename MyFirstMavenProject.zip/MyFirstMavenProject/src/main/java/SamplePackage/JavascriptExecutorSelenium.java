package SamplePackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavascriptExecutorSelenium {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
        
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		//js.executeAsyncScript(null, args)
		
		
		WebElement radiobtn = driver.findElement(By.xpath("//input[@value='radio1']"));
		
		// Click operation Javascriptexecutor
		js.executeScript("arguments[0].click();", radiobtn);
		
		//Scroll up scroll down
		//js.executeScript("window.scrollBy(0, document.body.scrollHeight)"); //Scroll down
		js.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(3000);
		
		js.executeScript("window.scrollTo(0,0)"); //Scroll up
		
		//Create Alret
		js.executeScript("alert('Completed successfully');");
		
		//Scrollinto view
		
		js.executeScript("arguments[0].scrollIntoView(true);", radiobtn);
		
		
		
		
		
		
		
	}

}
