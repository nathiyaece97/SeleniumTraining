package Sample;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyFirstSeleniumProject {
	static WebDriver  driver;
	
	// *********************** Launch browser ********************
	public void launchBrowser() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.manage().window().maximize();
	}
	
	// ************** read data from excel *********
	
	public String readData(int row, int col) throws Exception, IOException {
		File file= new File("C:\\Users\\686398\\OneDrive - Cognizant\\Desktop\\Datasheet.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rownum = sheet.getLastRowNum();
		
		String data = sheet.getRow(row).getCell(col).getStringCellValue();
		return data;
	}
	
	// ************************* login **********************
	public void login() throws Exception, Exception {
		String usernameval = readData(1,0);
		String password = readData(1,1);
		
		WebElement username = driver.findElement(By.xpath("//input[@placeholder='Username']"));
		WebElement password1= driver.findElement(By.xpath("//input[@name='inputPassword']"));
		WebElement signinBtn = driver.findElement(By.className("signInBtn"));
		
		username.sendKeys(usernameval);
		password1.sendKeys(password);
		signinBtn.click();
		
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		MyFirstSeleniumProject obj = new MyFirstSeleniumProject();
		obj.launchBrowser();
		obj.login();
		
	
		
	
		
		
		
		
		
		
		//Navigations
		
	//	driver.navigate().to("url");
	/*	driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().forward();
		
		Thread.sleep(2000);
		driver.navigate().refresh(); */
		
		
		
		
	//	driver.close(); - close active window 
		//driver.quit();  //close all the available windows
		
	//	driver.findElement(By.linkText("privacy policy")).click();
	//	driver.findElement(By.partialLinkText("privacy")).click();
		
		
		
		
		
		

	}

}
