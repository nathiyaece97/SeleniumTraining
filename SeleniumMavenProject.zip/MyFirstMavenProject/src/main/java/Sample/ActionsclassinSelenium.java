package Sample;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsclassinSelenium {

	static WebDriver driver;
	
	// *********************** Launch browser ********************
		public void launchBrowser() {
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://www.google.com/");
			driver.manage().window().maximize();
		}
		
	public void performAction() throws Exception {
		
		Actions action = new Actions(driver);
		action.contextClick().build().perform();
		Thread.sleep(3000);
		
		
		
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ActionsclassinSelenium obj= new ActionsclassinSelenium();
		obj.launchBrowser();
		
		

	}

}
