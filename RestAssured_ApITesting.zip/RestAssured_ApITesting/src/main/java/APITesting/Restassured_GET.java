package APITesting;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;


public class Restassured_GET {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		//given().
		System.out.println(given().queryParam("key", "qaclick123").queryParam("place_id","f37130972b0db2f8e49196483531e82b").when().get("/maps/api/place/get/json").then().extract().response().body().asString());
		
		

	}

}
