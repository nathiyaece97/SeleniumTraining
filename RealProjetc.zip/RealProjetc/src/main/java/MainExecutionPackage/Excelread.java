package MainExecutionPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelread {
		

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		FileInputStream file=new FileInputStream("C:\\Users\\686398\\OneDrive - Cognizant\\Desktop\\Datasheet.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		System.out.println(sheet.getSheetName());
		String data = sheet.getRow(1).getCell(1).getRawValue();
		System.out.println(data);

	}

}
