package ReusableLibrary;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ReusableComponents {
	
	@SuppressWarnings("deprecation")
	public static WebDriver invokeDriver(String url) {
		WebDriver driver = null;
		try {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
			//DesiredCapabilities capability = new DesiredCapabilities();
		//	ChromeOptions option = new ChromeOptions();
			//option.addArguments("--headless");
			//capability.setCapability(ChromeOptions.CAPABILITY, option);
			//option.merge(capability);
			DesiredCapabilities dc = new DesiredCapabilities();
			dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
			driver=new ChromeDriver(dc);
			driver.get(url);
			driver.manage().window().maximize();
			}
		catch(Exception e) {
			e.getStackTrace();
		}
		
		return driver;
	}
	
	
	
	
	public static String getExcelPath() throws Exception {
		String excelPath = "";
		try {
			Properties property = new Properties();
			String filepath  =System.getProperty("user.dir")+"\\Configuration.properties";
			System.out.println(filepath);
			BufferedReader br = new BufferedReader(new FileReader(filepath));
			property.load(br);
			excelPath = property.getProperty("excelPath");
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		return excelPath;
	}
	
	public static String readDataFromExcel(int row, int col) {
		
		String data="";
		try {
			
			FileInputStream file=new FileInputStream(getExcelPath());
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			data = sheet.getRow(row).getCell(col).getRawValue();		
			
		}catch(Exception e) {
			e.getStackTrace();
		}
		return data;
		
	}

}
