package ClassComponents;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import classobjects.EmployeeDashboardObject;
import classobjects.LoginObjects;

public class EmployeeDashboardComponent {

	public static void getQuickLaunchList(WebDriver driver) {
		// TODO Auto-generated method stub

		
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\686398\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		//WebDriver driver=new ChromeDriver();
		EmployeeDashboardObject obj = new EmployeeDashboardObject(driver);
		
		
		List<WebElement> ql = obj.quickLaunchList();
		
		for(WebElement ele : ql) {
			System.out.println(ele.getText());
		}
	}

}
