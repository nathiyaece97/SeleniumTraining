
public class StringToIntConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String s="-91283472332";
		  String s1[] = s.trim().split(" ");
	        int result = 0;
	        System.out.println(s1.length);
	        for(int i=0;i<s1.length;i++){
	            if(s1[i].matches("^[a-zA-Z]*$")){
	                break;
	            }
	            else if(s1[i].contains("-")){
	                String num = s1[i].split("-")[1];
                    try{
                    result = Integer.parseInt(num);
	                result=result*-1;
                    }
                    catch(Exception e){
                        //result = Long.parseLong(num);
	                result=0;
                    }
	               
	            }
	            else {
	            	  result = Integer.parseInt(s1[i]);
	            }
	        System.out.println(result);
	        }
	}

}
