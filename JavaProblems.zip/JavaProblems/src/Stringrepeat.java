import java.util.LinkedHashMap;

public class Stringrepeat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "Programming";
		char ar[] = s.toCharArray();

		for(int i=0;i<s.length()-1;i++){
			for(int j=0;j<s.length();j++){
				if(s.charAt(i)==s.charAt(j) && i!=j){
					System.out.print(s.charAt(i));
				}
			}
		}
		
		LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();
		for(int i=0;i<s.length();i++) {
			if(map.containsKey(ar[0])) {
				map.put(ar[0], 1);
				
			}
		}
					
	}

}
