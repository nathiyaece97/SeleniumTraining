package enumeration;

public enum enumsample {
	winter,summer;

	public static void main(String arg[]) {
		System.out.println("asdd"+enumsample.winter);
	}
}
