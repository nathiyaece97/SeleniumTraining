package MultiThreading;

public class FirstThread implements Runnable {

	public void run() {
		for(int i=0;i<5;i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(i);
		}
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirstThread t1= new FirstThread();
		Thread t = new Thread(t1);
		FirstThread t2= new FirstThread();
		Thread tt = new Thread(t2);
		FirstThread t3= new FirstThread();
		
		t.start();
		tt.start();
		//t3.start();
		

	}

}
