import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class removeduplicatefromsortedArrayII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int nums[]= {1,1,1,2,2,3};
		 List <Integer>al=new ArrayList<>();
	        for(int i=0;i<nums.length;i++){
	            al.add(nums[i]);
	        }
	        int j=0;
	        for(int i=0;i<al.size();i++){
	            int f= Collections.frequency(al,al.get(i));
	            if(f>2 || f==2){
	                for(int k=0;k<2;k++){
	                	//System.out.println(j+"* "+al.get(i)+"*i "+i);
	                    nums[j] = al.get(i);
	                    j++;
	                }
	                i=i+f-1;
	            }
	            else{
	               nums[j++]=al.get(i);
	            }
	            
				
			//}
		}
		System.out.println(j);

	}

}
