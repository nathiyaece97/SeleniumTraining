import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class FindLongestSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=" ";
		System.out.println(s.length());
		Set <String>set= new LinkedHashSet<>();
		for(int i=0;i<s.length();i++) {
			for(int j=i;j<s.length();j++) {
				set.add(s.substring(i,j+1));
			}
		}
		ArrayList<Integer> al=new ArrayList<>();
		System.out.println(set);
		for(String temp : set) {
			char a[]=temp.toCharArray();
			Set<Character> dup = new HashSet<>();
			for(int i=0;i<a.length;i++) {
				dup.add(a[i]);
			}
			if(dup.size()==temp.length()) {
				al.add(temp.length());
			}
			
		}
		
		Collections.sort(al);
		System.out.println(al.size());
	}

}
