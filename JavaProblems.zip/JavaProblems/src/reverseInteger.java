
public class reverseInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = -2147483648;
		 long res=0;
	        int result=0;
	        if(x==0){
	            result =0;
	        }
	        else{
	             String s = Integer.toString(x);
			  x=Math.abs(x);
		        String out = "";
		        int q = x;
		    
		        while(q!=0){
		            long rem = q%10;
	                res=res*10+rem;
		           // out+=rem;
		            q=q/10;
		        }
		      //res =  Integer.parseInt(out);
		        System.out.println(res);
		        if(s.contains("-")) {
		        	result=(int)res *-1;
		        	System.out.println(result +" "+res);
		        }
		        else {
		        	result =(int)res;
		        }
	            if(res>2147483647 || res<-2147483648){
	            	System.out.println("dfdsf");
	            	
	                result = 0;
	            }
	        System.out.println(result);
	        }
	}

}
// Best Solution

/*
class Solution {
public int reverse(int x) {
      long res=0;
    int result=0;
    if(x==0){
        return result;
    }
    else{
         String s = Integer.toString(x);
	  x=Math.abs(x);
        String out = "";
        int q = x;
    
        while(q!=0){
            long rem = q%10;
            res=res*10+rem;
           // out+=rem;
            q=q/10;
        }
      // res =  Integer.parseInt(out);
        if(res>2147483647 || res<-2147483648){
            result = 0;
        }
        else if(s.contains("-")) {
        	result=(int)res *-1;
        }
        else{
            result = (int)res;
        }
      
    return result;
    }
   
}
}
*/