import java.util.ArrayList;

public class removeduplicatesfromsortedarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int nums[] = {0,0,1,1,1,2,2,3,3,4};
		 int num1[]=nums;
	       ArrayList<Integer> al=new ArrayList<>();
	        int count=0;
	        int j=1;
	        for(int i=0;i<num1.length;i++){
			            if(!al.contains(nums[i])){
			                al.add(count,nums[i]);
	                        nums[count]=num1[i];
			                count++;
			            }
			            else{
			                al.add(nums[i]);
	                        nums[i]=num1[i];
			               // j--;
			            }
			        }
		        System.out.println(count);
		    
	/*	int num1[]=nums;
		int j=nums.length-1;
		 for(int i=0;i<num1.length;i++){
			 if(num1[i]==num1[i+1]) {
				// num1[i+1]=num1[i+2];
				 nums[j]=num1[i+1];
				 j--;
			 }
		 } */
		 
		
		

	}

}
