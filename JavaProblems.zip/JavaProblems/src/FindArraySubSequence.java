import java.util.*;

//import com.sun.tools.javac.util.ArrayUtils;

public class FindArraySubSequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {2, 4, 10 , 3 ,4 , 7, 8 , 2, 3, 7,1, 2};
		int x=3;
		int y=2;
		
		List al=Arrays.asList(a);
		
		int count=0;
		for(int i=0;i<a.length;i++) {
			if(a[i]==x) {
				for(int j=i+1;j<a.length;j++) {
					if(a[j]==y) {
						count++;
					}
				}
			}
			else if(a[i]==y){
				for(int j=i+1;j<a.length;j++) {
					if(a[j]==x) {
						count++;
					}
				}
			}
		}
		System.out.println(count);

		
	
	}

}
