package InterviewQuestions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CheckArray1ContainsArray2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {1,2,5,4,8,3};
		int a2[]= {1,2,9};
		
		//ArrayList<Integer> al= new ArrayList<>();
		List<Integer> al = Arrays.stream(a).boxed().collect(Collectors.toList());
		
		int count=0;
		for(int i=0;i<a2.length;i++) {
			if(!al.contains(a2[i])) {
				count=1;
				System.out.println("first array doesn't contain second array");
				break;
			}
		}
		if(count==0) {
			System.out.println("first array contain second array");
		}

	}

}
