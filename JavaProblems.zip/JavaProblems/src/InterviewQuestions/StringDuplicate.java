package InterviewQuestions;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class StringDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "JavaProgramming";
		char array[]=s.toCharArray();
		Set<Character> al=new LinkedHashSet<>();
		for(int i=0;i<array.length;i++) {
			al.add(array[i]);
		}
		
		for(char a: al) {
			System.out.print(a);
		}
		
		//using stream
		System.out.println(s.chars().distinct().collect(StringBuilder::new,
        StringBuilder::appendCodePoint,
        StringBuilder::append).toString());
		

	}

}
