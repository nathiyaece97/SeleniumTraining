package InterviewQuestions;

import java.util.Stack;

public class Parenthesis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input = "(())()";
		
		Stack<Character> stack = new Stack<>();
		String a="";
		
		int count=0;
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i)=='(') {
				stack.push(input.charAt(i));
				a+=(input.charAt(i));
			}
			else if(input.charAt(i)==')'){
				if(!stack.isEmpty()) {
					count++;
					a+=(input.charAt(i));
					stack.pop();
				}
				
			}
		}
		
		if(input.length()==count*2) {
			System.out.println("balanced");
		}
		else {
			System.out.println("Un balanced");
		}
		System.out.println(count+" "+a);
		
		
		

	}

}
