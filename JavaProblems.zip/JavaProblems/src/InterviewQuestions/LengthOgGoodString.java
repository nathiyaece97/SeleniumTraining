package InterviewQuestions;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
class LengthOgGoodString {
    public static void main(String args[] ) throws Exception {
        //BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String name = br.readLine();                // Reading input from STDIN
        //System.out.println("Hi, " + name + ".");    // Writing output to STDOUT

        ArrayList<Character> al= new ArrayList<>();
        int c=0;
        int j=0;
        for(int i=0;i<name.length();i++){
            if(name.charAt(i)=='a' || name.charAt(i)=='e' ||name.charAt(i)=='i' || name.charAt(i)=='o' || name.charAt(i)=='u'){
                al.add(name.charAt(i));
            }
            else{
                if(c<al.size()){
                    c=al.size();
                   
                    //i=j++;
                    
                }
                al.clear();
            }
        }
        if(c<al.size()) {
        	c=al.size();
        }
        System.out.println(c);
    }
}
