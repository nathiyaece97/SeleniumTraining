package InterviewQuestions;

import java.util.Arrays;

public class Matrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[][] ={{9,2,3 }, { 4, 1, 6 }, { 7, 8, 9 }};  
		
		// 9 2 3
		// 4 1 6
		// 7 8 9
		//Arrays.sort(a);
		
		int min = a[0][0];
		int max=0;
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				if(min>a[i][j]) {
					max=a[i][j];
					min=a[i][j];
					for(int k=0;k<a.length;k++) {
						if(max<a[k][j]) {
							max=a[k][j];
						}
					}
				}
			}
		}
		System.out.println(min +" "+max);
		
	}

}
