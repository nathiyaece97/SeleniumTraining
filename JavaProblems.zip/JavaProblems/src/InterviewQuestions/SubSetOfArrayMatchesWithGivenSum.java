package InterviewQuestions;

import java.util.ArrayList;

public class SubSetOfArrayMatchesWithGivenSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {1,2,5,4,8,3};
		int sum=7;
		
		ArrayList<Integer> al=new ArrayList<>();
		for(int i=0;i<a.length-1;i++) {
			if(a[i]==sum && !al.contains(sum)) {
				al.add(a[i]);
			}
			for(int j=i+1;j<a.length;j++) {
				al.add(a[i]+a[j]);
				al.add(a[i]+a[i+1]);
			}
		}
		
	}

}
