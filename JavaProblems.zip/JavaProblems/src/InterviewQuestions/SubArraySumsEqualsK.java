package InterviewQuestions;

import java.util.HashMap;

public class SubArraySumsEqualsK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int nums[]= {1,2,3,5}; int k=5;
		  int count = 0, sum = 0;
	        HashMap < Integer, Integer > map = new HashMap < > ();
	        map.put(0, 1);
	        for (int i = 0; i < nums.length; i++) {
	            sum += nums[i];
	             System.out.println(sum);
	            if (map.containsKey(sum - k))
	                count += map.get(sum - k);
	            map.put(sum, map.getOrDefault(sum, 0) + 1);
	        }
	           
	      System.out.println(count);
	      System.out.println(map);

	}

}
