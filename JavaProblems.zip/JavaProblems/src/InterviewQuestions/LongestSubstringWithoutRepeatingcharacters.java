package InterviewQuestions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;

public class LongestSubstringWithoutRepeatingcharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		String s=" ";
		LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();
        ArrayList<Integer> al = new ArrayList<>();
        String out ="";
       // if(s.length()!=0){
            for(int i=0,j=0;i<s.length();i++){
                if(map.containsKey(s.charAt(i))){
                    al.add(out.length());
                  map.clear();
                    out="";
                    j++;
                    i=j-1;
                   // i=map.get(0)+1;
                }
                else{
                    map.put(s.charAt(i),i);
                    out+=s.charAt(i);
                   // System.out.println(out);
                }
                  al.add(out.length());
            }
      
        Collections.sort(al);
        System.out.println(al);
        if(al.size()==0) {
        	 System.out.println(0);
        }
        else {
        System.out.println( al.get(al.size()-1));

        }
        
        
        
        
        
        
        
        
    // *************************** using string *************************************
        class Solution {
            public int lengthOfLongestSubstring(String s) {
                
                  String out="";
                int max=0;
                char a[]=s.toCharArray();
                for(int i=0,j=0;i<s.length();i++) {
                	if(out.contains(Character.toString(a[i]))){
                        if(out.length()>max){
                            max=out.length();
                        }
                		out="";
                        j++;
                        i=j-1;
                		
                	}
                	else {
                		out+=s.charAt(i);
                	}
                }
                 if(out.length()>max){
                    max=out.length();
                }
                return max;
            }
        }
        
        
	}
}


