package InterviewQuestions;

import java.util.ArrayList;

public class SubstringValidation {

	public static void main(String[] args) {
		
		/*Given a String containing characters.find the length of longest valid paranthesis sub string.
		Input : ((()
				Output : 2
				valid Substring : ()

				Input: )()())
				Output : 4
				valid Substring: ()() 
				
				*Input:  ()(()))))
Output: 6
valid Substring:  ()(())
*/

		// TODO Auto-generated method stub
		
		
		String input = "((((((()))))))))";
		char inputarr[]=input.toCharArray();
		String output="";
		int count=0;
		ArrayList<Character> al=new ArrayList<>();
		for(int i=0;i<inputarr.length-1;i++) {
			for(int j=i+1;j<inputarr.length;j++) {
				if(inputarr[i]=='(') {
					if(inputarr[j]==')') {
						count+=2;
						String temp = Character.toString(input.charAt(i))+Character.toString(input.charAt(j));
						al.add(i,inputarr[i]);
						al.add(j,inputarr[j]);
						inputarr[j]='0';
						//System.out.println(input);
						break;
						
					}
				}
					
			}
			
		}
		
		System.out.println(count);
		System.out.println(al);
		

	}

}
