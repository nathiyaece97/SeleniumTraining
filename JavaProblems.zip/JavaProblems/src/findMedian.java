
public class findMedian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int nums1[]= {1,3};
		int nums2[]= {2};
		 int nums3[]=new int[nums1.length+nums2.length];
	        System.arraycopy(nums1,0,nums3,0,nums1.length);
	        System.arraycopy(nums2,0,nums3,nums1.length,nums2.length);
	        double result=0.0;
	        int s= nums3.length;
	        if(s%2==0){
	            result = (double)(nums3[s/2-1]+nums3[s/2])/2;
	        }
	        else{
	            result = nums3[s/2];
	        }
	 System.out.println(result); 
		
	/*	double a=3;
		double b=2;
		System.out.println(a/b); */
	 

	}

}
