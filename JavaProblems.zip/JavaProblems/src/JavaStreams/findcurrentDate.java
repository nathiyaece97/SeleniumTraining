package JavaStreams;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class findcurrentDate {
	
	public static void main(String arg[]) {
		DateFormat dateformat= new SimpleDateFormat("MM/dd/yyyy");
	//	Date date = new Date();
		//String currentdate = dateformat.format(date);
		//System.out.println(currentdate+90);
		
		Calendar c= Calendar.getInstance();
		c.add(Calendar.DATE, 90);
		Date d=c.getTime();
		System.out.println(dateformat.format(d).split("/")[1]);
		
		
		
	}

}
