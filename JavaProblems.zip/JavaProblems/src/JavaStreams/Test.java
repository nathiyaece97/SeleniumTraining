package JavaStreams;

//public class Test {
	
	public class Test
	{
	public static void main(String args[])
	{
	boolean x = true;
	int a;
	
	if(x) 
		a = x ? 1: 2;
	else 
		a = x ? 3: 4;
	System.out.println(args[0]);
	
	
	}
	}

//}
