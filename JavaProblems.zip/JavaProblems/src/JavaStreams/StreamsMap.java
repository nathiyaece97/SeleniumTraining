package JavaStreams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamsMap {

	public static <T> void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Demonstration of map
		List<Integer> number=Arrays.asList(10,2,33,1,5);
		List<Integer> square = (List)number.stream().map(x->x*x).collect(Collectors.toList());
		System.out.println(square);
		
		//Demonstration of For each
		number.stream().map(x->x*x).forEach(y->System.out.println(y));
		
		//Demonstration of filter
		List<Integer> filter = number.stream().filter(x->x>3).collect(Collectors.toList());
		System.out.println(filter);
		
		List<String> name = Arrays.asList("Java","Program","Placement");
		name.stream().filter(s->s.startsWith("P")).forEach(y->System.out.println(y));
		
		//Sorted method
		name.stream().sorted().forEach(y->System.out.println(y));
		
		 
		//reduce method
		int even =number.stream().reduce(0,(ans,i)-> ans+i);
		System.out.println("even"+even);
		
		//get maximum number from Array
		Optional<Integer> max = number.stream().reduce((n1,n2)->n1>n2?n1:n2);
		
		if(max.isPresent())
		System.out.println(max.get());
		
		
		//convert array to arraylist
		int a[]= {1,3,4,5,9};
		List<Integer> al = Arrays.stream(a).boxed().collect(Collectors.toList());

	}

}
