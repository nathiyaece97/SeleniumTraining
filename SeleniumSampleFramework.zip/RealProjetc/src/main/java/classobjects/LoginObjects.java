package classobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginObjects {
	static WebDriver driver;
	
	public LoginObjects(WebDriver driver){
		this.driver=driver;
	}

	//Page Object	
	
	By username = By.id("txtUsername");
	By password = By.name("txtPassword");
	By loginbtn = By.xpath("//input[@id='btnLogin']");
	
	public WebElement getUsername() {
		return driver.findElement(username);
	}
	
	public WebElement getpassword() {
		return driver.findElement(password);
	}
	
	public WebElement clickLogin() {
		return driver.findElement(loginbtn);
	}
	
	
	
	
	

}
