package classobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EmployeeDashboardObject {
	
	static WebDriver driver;
	public EmployeeDashboardObject(WebDriver driver){
		this.driver=driver;
	}

	
	
	By quicklaunch = By.xpath("//table[@class='quickLaungeContainer']//tr/td/div/a/span");
	
	public List<WebElement> quickLaunchList() {
		return driver.findElements(quicklaunch);
	}
	
}
