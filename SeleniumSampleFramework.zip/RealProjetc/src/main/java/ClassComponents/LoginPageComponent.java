package ClassComponents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import ReusableLibrary.ReusableComponents;
import classobjects.LoginObjects;

public class LoginPageComponent extends ReusableComponents{
	
	
	public static void loginMethod(WebDriver driver) {
		 
		LoginObjects obj = new LoginObjects(driver);
		
		String username = readDataFromExcel(1,0);
		String password = readDataFromExcel(1,1);
		
		obj.getUsername().sendKeys(username);
		obj.getpassword().sendKeys(password);
		obj.clickLogin().click();
			
		
		
		
		
	}


}
