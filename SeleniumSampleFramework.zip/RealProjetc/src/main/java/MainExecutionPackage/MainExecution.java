package MainExecutionPackage;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ClassComponents.EmployeeDashboardComponent;
import ClassComponents.LoginPageComponent;
import ReusableLibrary.ReusableComponents;

public class MainExecution extends ReusableComponents {

	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		/*ReusableComponents reuseobj = new ReusableComponents();
		LoginPageComponent loginobj = new LoginPageComponent();
		EmployeeDashboardComponent dashobj = new EmployeeDashboardComponent(); */
		
		String url = "https://www.practo.com/plus/corporate" ;  //readDataFromExcel(1,2);
		
		System.out.println("https://www.practo.com/plus/corporate");
		
		driver = ReusableComponents.invokeDriver(url);
		driver.findElement(By.xpath("//button[contains(text(),'Schedule a demo')]")).click();
		//Thread.sleep(3000);
		
		/*Set<String> li = driver.getWindowHandles();
		System.out.println(li.size()); */
		try {
			
			new WebDriverWait(driver, 10)
	        .until(ExpectedConditions.alertIsPresent());

	Alert al = driver.switchTo().alert();
	al.accept();
		 Alert alert = driver.switchTo().alert();
		 System.out.println(alert.getText());
		}
		catch(Exception e) {
			System.out.println(e);
		}
		//System.out.println(alert.getText());

		
		//EmployeeDashboardComponent.getQuickLaunchList(driver);
		
	}

}
